﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3_ps10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("\nInput first integer:");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input second integer:");
            num2 = Convert.ToInt32(Console.ReadLine());

            //if one is negative and other is positive
            Console.WriteLine("expected output:");
            Console.WriteLine((num1 < 0 && num2 > 0) || (num1 > 0 && num2 < 0));

            Console.ReadLine();
        }
    }
}
