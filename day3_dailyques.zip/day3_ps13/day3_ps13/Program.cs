﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3_ps13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int m, km;
            Console.WriteLine("enter input in meter(m): ");
            m = Int32.Parse(Console.ReadLine());

            Console.WriteLine("enter input in kilometer(km): ");
            km = Int32.Parse(Console.ReadLine());


        }
    }
}
