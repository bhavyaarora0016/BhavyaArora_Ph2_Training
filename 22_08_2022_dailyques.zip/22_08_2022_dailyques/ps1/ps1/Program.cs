﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ps1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = new int[10];

            Console.WriteLine("store and print elements in an array: ");
            Console.WriteLine("input 10 elements: ");

            for (int i = 0; i < 10; i++)
            {
                Console.Write("element - {0}: ", i);
                arr1[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.Write("Elements in array are: ");
            for (int i = 0; i < 10; i++)
            {
                Console.Write("{0} ", arr1[i]);
            }

            Console.ReadLine();

        }
    }
}
