﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ps2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            int[] arr2 = new int[10];


            Console.WriteLine("Enter number of elements to store: ");
            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the elements of the array: ");
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine("element - {0} : ", i);
                arr2[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("values stored are: ");
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine("{0} ", arr2[i]);

            }

            Console.WriteLine("stored values in reverse order are:");
            for (int i = num-1; i >= 0; i--)
            {
                Console.WriteLine("{0} ", arr2[i]);
            }

            Console.ReadKey();
        }
    }
}
