﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day4_ps15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i <= 25; i++)
            {
                for (int j = 25; j >=0; j--)
                {
                    if (i > j)
                    {
                        break;
                    }
                    Console.WriteLine("Crossed over! at {0}, {1}", i, j);
                }
            }
            Console.ReadLine();
        }
    }
}
