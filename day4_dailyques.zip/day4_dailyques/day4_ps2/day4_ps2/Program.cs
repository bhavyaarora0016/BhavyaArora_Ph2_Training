﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day4_ps2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;

            Console.WriteLine("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.WriteLine("First number ({0}) is the greatest", num1);
                }
                else
                {
                    Console.WriteLine("Third number ({0}) is the greatest", num3);
                }
            }
            else if (num2 > num3)
                Console.WriteLine("Second number ({0}) is the greatest", num2);
            else
                Console.WriteLine("Third number ({0}) is the greatest", num3);

            Console.ReadLine();
            



        }
    }
}
