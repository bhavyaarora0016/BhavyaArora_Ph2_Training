﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day4_ps3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char c1, c2;

            Console.WriteLine("Enter first character:");
            c1 = Console.ReadLine()[0];

            Console.WriteLine("Enter second character: ");
            c2 = Console.ReadLine()[0];

            if (c1 == c2)
                Console.WriteLine("Both characters are equal");
            else
                Console.WriteLine("Chaarcters not equal");

            Console.WriteLine("---------------------");
            Console.ReadLine();


            //string s1 = "test";
            //string s2 = "TEST";

            //Console.WriteLine(s1 == s2);
            //Console.ReadLine();
        }
    }
}
