﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day4_ps13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;

            Console.WriteLine("Enter number: ");
            num = Convert.ToInt32(Console.ReadLine());

            if (num % 2 == 0)
            {
                Console.WriteLine("Given number is Even");
            }
            else
            {
                Console.WriteLine("Givden number is Odd");
            }

            if (num % 10 == 0)
            {
                Console.WriteLine("Given number is multiple of 10");
            }
            else
            {
                Console.WriteLine("Given number is not a multiple of 10");
            }

            if (num == 0)
            {
                Console.WriteLine("Given number is Zero");
            }
            else
            {
                Console.WriteLine("Given number is not Zero");
            }
            

            if (num > 100)
            {
                Console.WriteLine("Given number is too large");
            }
            else
            {
                Console.WriteLine("Given number is less than 100");
            }


            Console.ReadLine();

        }
    }
}
