﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day4_ps10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, i, r;
            int sum = 0;

            Console.WriteLine("Enter a number: ");
            num = Convert.ToInt32(Console.ReadLine());

            for (i = num; i != 0; i = i / 10)
            {
                r = i % 10;
                sum = sum * 10 + r;
            }

            Console.WriteLine("Reverse order of given number is {0}", sum);

            Console.ReadLine();
        }
    }
}
