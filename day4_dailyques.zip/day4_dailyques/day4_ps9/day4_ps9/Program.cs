﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day4_ps9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            int sum=0;

            Console.WriteLine("Enter number of terms: ");
            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("The odd numbers are: ");

            for (int i = 1; i <= num; i++)
            {
                Console.Write("{0} ", 2*i-1);
                sum += 2 * i - 1;
            }
            Console.WriteLine("\nsum of odd natural number upto {0} terms: {1}", num, sum);

            Console.ReadLine();
        }
    }
}
