﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day3_ps8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;

            Console.Write("Enter a number: ");
            num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Expected output: ");
            Console.WriteLine("{0}{0}{0}", num);
            Console.WriteLine("{0} {0}", num);
            Console.WriteLine("{0} {0}", num);
            Console.WriteLine("{0} {0}", num);
            Console.WriteLine("{0}{0}{0}", num);

            Console.ReadLine();
        }
    }
}
